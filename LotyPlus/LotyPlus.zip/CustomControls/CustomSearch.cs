﻿using System;
namespace LotyPlus.CustomControls
{
    public class CustomSearch : SearchBar
    {
    }
}

